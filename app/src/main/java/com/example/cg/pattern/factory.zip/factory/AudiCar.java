package com.example.cg.pattern.factory;

/**
 * 奥迪汽车
 */
public class AudiCar extends Car{
    @Override
    public void run() {
        System.out.println("奥迪汽车开始跑了！！！");
    }
}
