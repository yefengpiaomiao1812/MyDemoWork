package com.example.cg.pattern.factory;

/**
 * 宝马汽车
 */
public class BmwCar extends Car{
    @Override
    public void run() {
        System.out.println("宝马汽车开始跑了！！！");
    }
}
