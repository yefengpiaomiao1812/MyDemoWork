package com.example.cg.pattern.factory;

/**
 * 抽象汽车类
 */
public abstract class Car {

    // 抽象汽车的方法  rnu()
    public abstract void run();
}
